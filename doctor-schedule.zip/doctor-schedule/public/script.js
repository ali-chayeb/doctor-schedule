const API_BASE = '/api';

document.addEventListener('DOMContentLoaded', () => {
    loadDoctors();
    loadLocations();
    loadStats();
    
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    document.getElementById('schedule-month').value = `${year}-${month}`;
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`${tabId}-tab`).classList.add('active');
            if (tabId === 'schedule') loadSchedule();
            if (tabId === 'stats') loadStats();
        });
    });
});

async function loadDoctors() {
    try {
        const response = await fetch(`${API_BASE}/doctors`);
        const doctors = await response.json();
        const container = document.getElementById('doctors-list');
        if (doctors.length === 0) {
            container.innerHTML = '<p>لا يوجد أطباء. أضف طبيباً جديداً!</p>';
            return;
        }
        container.innerHTML = `<div class="doctors-grid">${doctors.map(doctor => `
            <div class="doctor-card">
                <h3>👨‍⚕️ ${doctor.name}</h3>
                <p>📅 تاريخ البدء: ${doctor.start_date || 'غير محدد'}</p>
                <p>📊 المناوبات: ${doctor.shifts_count || 0}</p>
                <button onclick="deleteDoctor('${doctor._id}')">حذف</button>
                <button onclick="editDoctor('${doctor._id}')">تعديل</button>
            </div>
        `).join('')}</div>`;
        
        const doctorSelect = document.getElementById('assign-doctor');
        doctorSelect.innerHTML = '<option value="">اختر الطبيب</option>' + doctors.map(d => `<option value="${d._id}">${d.name}</option>`).join('');
    } catch (error) { 
        console.error(error);
        document.getElementById('doctors-list').innerHTML = '<p>خطأ في تحميل الأطباء</p>';
    }
}

async function addDoctor() {
    const name = document.getElementById('doctor-name').value;
    const startDate = document.getElementById('doctor-start-date').value;
    if (!name) { alert('الرجاء إدخال اسم الطبيب'); return; }
    try {
        await fetch(`${API_BASE}/doctors`, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ name, start_date: startDate }) 
        });
        document.getElementById('doctor-name').value = '';
        document.getElementById('doctor-start-date').value = '';
        loadDoctors(); 
        loadStats();
        alert('تم إضافة الطبيب بنجاح');
    } catch(error) {
        alert('خطأ في إضافة الطبيب');
    }
}

async function deleteDoctor(id) { 
    if (confirm('هل أنت متأكد من حذف هذا الطبيب؟')) { 
        await fetch(`${API_BASE}/doctors/${id}`, { method: 'DELETE' }); 
        loadDoctors(); 
        loadStats(); 
    } 
}

function editDoctor(id) { 
    const newName = prompt('أدخل الاسم الجديد للطبيب:'); 
    if (newName) { 
        fetch(`${API_BASE}/doctors/${id}`, { 
            method: 'PUT', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ name: newName }) 
        }).then(() => { 
            loadDoctors(); 
            loadStats(); 
        }); 
    } 
}

async function loadLocations() {
    try {
        const response = await fetch(`${API_BASE}/locations`);
        const locations = await response.json();
        const container = document.getElementById('locations-list');
        if (locations.length === 0) {
            container.innerHTML = '<p>لا توجد أماكن</p>';
            return;
        }
        container.innerHTML = `<div class="locations-grid">${locations.map(loc => `<div class="location-card"><h3>📍 ${loc.name}</h3></div>`).join('')}</div>`;
        const locationSelect = document.getElementById('assign-location');
        locationSelect.innerHTML = '<option value="">اختر المكان</option>' + locations.map(l => `<option value="${l._id}">${l.name}</option>`).join('');
    } catch (error) { 
        console.error(error);
    }
}

async function addLocation() {
    const name = document.getElementById('location-name').value;
    if (!name) { alert('الرجاء إدخال اسم المكان'); return; }
    await fetch(`${API_BASE}/locations`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
    document.getElementById('location-name').value = '';
    loadLocations();
}

async function loadSchedule() {
    const monthValue = document.getElementById('schedule-month').value;
    if (!monthValue) return;
    const [year, month] = monthValue.split('-');
    try {
        const response = await fetch(`${API_BASE}/shifts/${year}/${month}`);
        const shifts = await response.json();
        const container = document.getElementById('schedule-table');
        if (shifts.length === 0) { 
            container.innerHTML = '<p>لا توجد مناوبات لهذا الشهر</p>'; 
            return; 
        }
        let html = '<div class="schedule-table"><table><thead><tr><th>التاريخ</th><th>المكان</th><th>الطبيب</th></tr></thead><tbody>';
        shifts.forEach(shift => { 
            html += `<tr>
                <td>${shift.date}</td>
                <td>${shift.location_name}</td>
                <td>${shift.doctor_name}</td>
            </tr>`; 
        });
        html += '</tbody></table></div>';
        container.innerHTML = html;
    } catch (error) { 
        console.error(error);
        document.getElementById('schedule-table').innerHTML = '<p>خطأ في تحميل الجدول</p>';
    }
}

async function assignShift() {
    const doctor_id = document.getElementById('assign-doctor').value;
    const location_id = document.getElementById('assign-location').value;
    const date = document.getElementById('assign-date').value;
    if (!doctor_id || !location_id || !date) { 
        alert('الرجاء ملء جميع الحقول'); 
        return; 
    }
    try {
        await fetch(`${API_BASE}/shifts/assign`, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ doctor_id, location_id, date }) 
        });
        document.getElementById('assign-date').value = '';
        loadSchedule(); 
        loadDoctors(); 
        loadStats();
        alert('✅ تم توزيع المناوبة بنجاح');
    } catch(error) {
        alert('خطأ في توزيع المناوبة');
    }
}

async function loadStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        const stats = await response.json();
        const container = document.getElementById('stats-content');
        container.innerHTML = `<div class="stats-grid">
            <div class="stat-card"><h3>👨‍⚕️ إجمالي الأطباء</h3><div class="number">${stats.total_doctors}</div></div>
            <div class="stat-card"><h3>📋 إجمالي المناوبات</h3><div class="number">${stats.total_shifts}</div></div>
            <div class="stat-card"><h3>⚖️ متوسط المناوبات</h3><div class="number">${stats.avg_shifts_per_doctor}</div></div>
        </div>`;
    } catch (error) { 
        console.error(error);
    }
}

function exportToExcel() {
    const table = document.querySelector('#schedule-table table');
    if (!table) { 
        alert('لا يوجد جدول لتحميله'); 
        return; 
    }
    let csv = []; 
    const rows = table.querySelectorAll('tr');
    for (let i = 0; i < rows.length; i++) { 
        const row = []; 
        const cols = rows[i].querySelectorAll('td, th'); 
        for (let j = 0; j < cols.length; j++) { 
            row.push(cols[j].innerText); 
        } 
        csv.push(row.join(',')); 
    }
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' }); 
    const url = URL.createObjectURL(blob); 
    const a = document.createElement('a'); 
    a.href = url; 
    a.download = 'schedule.csv'; 
    a.click(); 
    URL.revokeObjectURL(url);
}
